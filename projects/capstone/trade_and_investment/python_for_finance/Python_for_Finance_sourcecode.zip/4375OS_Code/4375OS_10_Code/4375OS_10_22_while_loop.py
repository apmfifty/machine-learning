"""
  Name     : 4375OS_10_22_while_loop.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

i=1
while(i<=4):
    print(i)
    i+=1

# infinitive loop !!!!!!!!
i=1
while(i!=2.1):
    print(i)
    i+=1

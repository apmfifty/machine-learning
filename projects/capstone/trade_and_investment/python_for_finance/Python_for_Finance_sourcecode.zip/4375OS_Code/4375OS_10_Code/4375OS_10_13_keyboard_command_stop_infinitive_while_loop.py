"""
  Name     : 4375OS_10_13_keyboard_command_stop_infinitive_while_loop.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""


# using ctr-c or ctr-enter to stop
i=1
while True:
      print i
      #i+=1    
    
    
"""
  Name     : 4375OS_10_03_for_loop_descenging_order.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

for i in range(5,1,-1):
    print i
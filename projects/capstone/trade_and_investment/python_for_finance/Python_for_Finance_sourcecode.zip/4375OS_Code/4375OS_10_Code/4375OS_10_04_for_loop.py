"""
  Name     : 4375OS_10_04_for_loop.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

for i in xrange(1,10,3):
    print i

for j in xrange(5,1,-1):
    print j
    
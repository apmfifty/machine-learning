"""
  Name     : 4375OS_10_11_while_loop.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

i=1
while i<5:
    print i
    i+=1
    
    
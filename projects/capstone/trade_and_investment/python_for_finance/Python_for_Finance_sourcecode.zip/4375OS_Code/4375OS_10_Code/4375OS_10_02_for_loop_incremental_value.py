"""
  Name     : 4375OS_10_02_for_loop_incremental_value.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

for i in range(1,10,3):
    print i
"""
  Name     : 4375OS_10_20_loop_through_list.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

x=list(range(10))
for i in x:
    print i
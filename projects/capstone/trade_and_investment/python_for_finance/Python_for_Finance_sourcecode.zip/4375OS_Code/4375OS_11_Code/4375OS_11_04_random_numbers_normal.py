"""
  Name     : 4375OS_11_03_generate_random_numbers.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import scipy as sp
for i in range(10):
    print sp.random.normal()
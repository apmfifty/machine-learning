"""
  Name     : 4375OS_11_18_forecast_long_term.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
import scipy as sp
x=load('c:/temp/ffMonthly.pickle')






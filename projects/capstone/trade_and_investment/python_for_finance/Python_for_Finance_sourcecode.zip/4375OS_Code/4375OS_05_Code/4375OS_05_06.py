"""
  Name     : 4375OS_05_06_log_exp_sqrt.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

from math import log, exp, sqrt
print round(log(2.3,4))
print round(sqrt(3.7),4)

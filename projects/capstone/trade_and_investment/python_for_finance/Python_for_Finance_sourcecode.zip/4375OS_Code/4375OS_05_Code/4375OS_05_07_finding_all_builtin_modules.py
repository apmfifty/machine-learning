"""
  Name     : 4375OS_05_07_finding_all_builtin_modules.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import sys as s
print s.builtin_module_names
"""
  Name     : 4375OS_05_09_try_import_an_uninstalled_module.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import quant   # you will see an error message
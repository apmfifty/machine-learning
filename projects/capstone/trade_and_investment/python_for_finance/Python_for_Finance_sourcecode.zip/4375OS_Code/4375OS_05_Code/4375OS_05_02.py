"""
  Name     : 4375OS_05_02.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import sys as s
import time as tt
import numpy as np
import matplotlib as mp

"""
  Name     : 4375OS_05_01_square_root.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import math
x=math.sqrt(3)
round(x,4)

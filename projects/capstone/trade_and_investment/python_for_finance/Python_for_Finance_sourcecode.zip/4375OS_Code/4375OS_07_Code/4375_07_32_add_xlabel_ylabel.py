"""
  Name     : 4375OS_07_32_numbers.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

from matplotlib.pyplot import *
plot([1,2,3,10])
xlabel("x- axis")
ylabel("my numbers")
show()

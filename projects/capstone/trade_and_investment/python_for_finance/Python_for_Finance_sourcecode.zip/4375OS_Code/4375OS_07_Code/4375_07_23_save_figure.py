"""
  Name     : 4375OS_07_24_save_figure.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

from matplotlib.pylab import *
plot([1,1,4,5,10,11])
savefig("test.pdf")

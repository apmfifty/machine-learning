"""
  Name     : 4375OS_03_04_fv_f.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
def fv_f_due(pv,r,n):
    return pv*(1+r)**n*(1+R)

"""
  Name     : 4375OS_03_08_pv_perpetuity.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
def pv_perpetuity(c,r):
    return c/r

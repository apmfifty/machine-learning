"""
  Name     : 4375OS_03_05_pv_f_due.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
def pv_f_due(fv,r,n):
    return fv/(1+r)**n*(1+R) 

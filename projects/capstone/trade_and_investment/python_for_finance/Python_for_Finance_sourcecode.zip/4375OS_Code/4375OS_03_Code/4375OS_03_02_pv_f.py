"""
  Name     : 4375OS_03_02_pv_f.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
def pv_f(fv,r,n):
    return fv/(1+r)**n 

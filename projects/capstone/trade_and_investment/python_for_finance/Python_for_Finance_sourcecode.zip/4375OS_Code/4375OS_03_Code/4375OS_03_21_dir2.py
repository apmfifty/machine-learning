"""
  Name     : 4375OS_03_21_dir2.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

def dir2(path):
    from os import listdir
    print(listdir(path))    

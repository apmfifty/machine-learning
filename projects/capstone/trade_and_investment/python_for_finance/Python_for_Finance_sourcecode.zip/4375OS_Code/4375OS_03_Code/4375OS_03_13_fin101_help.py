"""
  Name     : 4375OS_03_13_fin101.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

def fin101():
    """
    1) Basic functions:
       pv_f,fv_f
    2) How to use pv_f?
       >>>help(pv_f)
    """

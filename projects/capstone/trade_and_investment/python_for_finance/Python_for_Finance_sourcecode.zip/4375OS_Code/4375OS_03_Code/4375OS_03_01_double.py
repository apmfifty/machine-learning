"""
  Name     : 4375OS_03_01_double.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/25/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
def double(n):
    """
        Double an input value
        e.g., double(5)
        10
    """
    return 2*n

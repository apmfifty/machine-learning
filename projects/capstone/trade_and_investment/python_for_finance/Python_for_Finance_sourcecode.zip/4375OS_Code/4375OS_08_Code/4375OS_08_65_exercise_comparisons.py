"""
  Name     : 4375OS_08_65_exercise_comparisons.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import pandas as pd
x=pd.read_csv("http://chart.yahoo.com/table.csv?s=IBM")


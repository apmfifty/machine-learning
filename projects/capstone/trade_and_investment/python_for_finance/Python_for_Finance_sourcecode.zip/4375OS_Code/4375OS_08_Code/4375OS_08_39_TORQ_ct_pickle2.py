"""
  Name     : 4375OS_08_39_TORQ_ct_pickle.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import pandas as pd
ct=load('c:/temp/TORQct.pickle')
"""
  Name     : 4375OS_08_56_item_by_item_divisoin.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

x=np.array([1,2,3],dtype='float')
y=np.array([2,2,4],dtype='float')
print np.divide(x,y)



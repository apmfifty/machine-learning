"""
  Name     : 4375OS_06_10_list.py
  Book     : Python for Finance
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 12/26/2013
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
x=[1,2,"John", "M", "Student"]

print 'type is ',type(x)


